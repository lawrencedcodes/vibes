/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        'off-white': '#F9F9F9',
        'primary-green': '#3D553A',
        'secondary-green': '#A3B8A1',
        'earth-brown': '#8A6F5E',
        'text-dark': '#212121',
        'text-gray': '#424242',
        'success-green': '#4CAF50',
      },
      fontFamily: {
        'heading': ['Poppins', 'sans-serif'],
        'body': ['Inter', 'sans-serif'],
      },
    },
  },
  plugins: [],
};