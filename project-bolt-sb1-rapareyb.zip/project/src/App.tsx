import React, { useState } from 'react';
import Header from './components/Header';
import Navigation from './components/Navigation';
import SoilCalculator from './components/SoilCalculator';
import SeedPlanner from './components/SeedPlanner';
import FertilizerCalculator from './components/FertilizerCalculator';
import AffiliateSection from './components/AffiliateSection';
import Footer from './components/Footer';

export type CalculatorType = 'soil' | 'seed' | 'fertilizer';

function App() {
  const [activeCalculator, setActiveCalculator] = useState<CalculatorType>('soil');

  return (
    <div className="min-h-screen bg-off-white">
      <Header />
      <Navigation 
        activeCalculator={activeCalculator} 
        setActiveCalculator={setActiveCalculator} 
      />
      
      <main className="container mx-auto px-4 py-8 max-w-4xl">
        {activeCalculator === 'soil' && <SoilCalculator />}
        {activeCalculator === 'seed' && <SeedPlanner />}
        {activeCalculator === 'fertilizer' && <FertilizerCalculator />}
        
        <AffiliateSection />
      </main>
      
      <Footer />
    </div>
  );
}

export default App;