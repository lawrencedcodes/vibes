import React from 'react';

interface InputFieldProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  unit?: string;
  onUnitChange?: (unit: any) => void;
  units?: string[];
  fixedUnit?: boolean;
}

const InputField: React.FC<InputFieldProps> = ({
  label,
  value,
  onChange,
  unit,
  onUnitChange,
  units = [],
  fixedUnit = false,
}) => {
  const isInvalid = value && (isNaN(parseFloat(value)) || parseFloat(value) <= 0);

  return (
    <div>
      <label className="block text-sm font-body font-semibold text-text-gray mb-2">
        {label}:
      </label>
      <div className="flex gap-2">
        <input
          type="number"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          min="0"
          step="0.1"
          className={`flex-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 font-body ${
            isInvalid
              ? 'border-red-500 focus:ring-red-200'
              : 'border-secondary-green focus:ring-primary-green focus:border-primary-green'
          }`}
          placeholder="Enter value"
        />
        {unit && (
          fixedUnit ? (
            <div className="px-4 py-2 bg-secondary-green/10 border border-secondary-green rounded-lg font-body text-text-gray">
              {unit}
            </div>
          ) : (
            <select
              value={unit}
              onChange={(e) => onUnitChange?.(e.target.value)}
              className="px-3 py-2 border border-secondary-green rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-green focus:border-primary-green font-body"
            >
              {units.map((unitOption) => (
                <option key={unitOption} value={unitOption}>
                  {unitOption}
                </option>
              ))}
            </select>
          )
        )}
      </div>
      {isInvalid && (
        <p className="text-red-500 text-sm font-body mt-1">Please enter a valid positive number</p>
      )}
    </div>
  );
};

export default InputField;