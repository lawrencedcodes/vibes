import React, { useState, useEffect } from 'react';
import { Calculator } from 'lucide-react';
import InputField from './InputField';
import ResultsCard from './ResultsCard';

const SoilCalculator: React.FC = () => {
  const [shape, setShape] = useState<'rectangle' | 'circle'>('rectangle');
  const [length, setLength] = useState<string>('');
  const [width, setWidth] = useState<string>('');
  const [diameter, setDiameter] = useState<string>('');
  const [depth, setDepth] = useState<string>('');
  const [lengthUnit, setLengthUnit] = useState<'feet' | 'inches'>('feet');
  const [widthUnit, setWidthUnit] = useState<'feet' | 'inches'>('feet');
  const [diameterUnit, setDiameterUnit] = useState<'feet' | 'inches'>('feet');
  const [depthUnit, setDepthUnit] = useState<'inches' | 'cm'>('inches');
  const [results, setResults] = useState<any>(null);

  const calculateVolume = () => {
    let areaInches = 0;
    let depthInches = 0;

    // Convert depth to inches
    if (depthUnit === 'cm') {
      depthInches = parseFloat(depth) / 2.54;
    } else {
      depthInches = parseFloat(depth);
    }

    // Calculate area based on shape
    if (shape === 'rectangle') {
      const lengthInches = lengthUnit === 'feet' ? parseFloat(length) * 12 : parseFloat(length);
      const widthInches = widthUnit === 'feet' ? parseFloat(width) * 12 : parseFloat(width);
      areaInches = lengthInches * widthInches;
    } else {
      const diameterInches = diameterUnit === 'feet' ? parseFloat(diameter) * 12 : parseFloat(diameter);
      const radius = diameterInches / 2;
      areaInches = Math.PI * radius * radius;
    }

    // Calculate volumes
    const cubicInches = areaInches * depthInches;
    const cubicFeet = cubicInches / 1728;
    const cubicYards = cubicFeet / 27;
    const bags2CuFt = Math.ceil(cubicFeet / 2);
    const bags075CuFt = Math.ceil(cubicFeet / 0.75);

    return {
      cubicFeet: cubicFeet.toFixed(2),
      cubicYards: cubicYards.toFixed(2),
      bags2CuFt,
      bags075CuFt,
    };
  };

  useEffect(() => {
    const allInputsValid = () => {
      if (shape === 'rectangle') {
        return length && width && depth && 
               !isNaN(parseFloat(length)) && 
               !isNaN(parseFloat(width)) && 
               !isNaN(parseFloat(depth)) &&
               parseFloat(length) > 0 &&
               parseFloat(width) > 0 &&
               parseFloat(depth) > 0;
      } else {
        return diameter && depth && 
               !isNaN(parseFloat(diameter)) && 
               !isNaN(parseFloat(depth)) &&
               parseFloat(diameter) > 0 &&
               parseFloat(depth) > 0;
      }
    };

    if (allInputsValid()) {
      setResults(calculateVolume());
    } else {
      setResults(null);
    }
  }, [shape, length, width, diameter, depth, lengthUnit, widthUnit, diameterUnit, depthUnit]);

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-md p-6">
        <div className="flex items-center gap-3 mb-6">
          <Calculator className="w-6 h-6 text-primary-green" />
          <h2 className="text-2xl font-heading font-semibold text-text-dark">
            Soil, Compost & Mulch Calculator
          </h2>
        </div>

        <div className="space-y-6">
          {/* Shape Selection */}
          <div>
            <label className="block text-sm font-body font-semibold text-text-gray mb-3">
              Garden Bed Shape:
            </label>
            <div className="flex gap-4">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="radio"
                  value="rectangle"
                  checked={shape === 'rectangle'}
                  onChange={(e) => setShape(e.target.value as 'rectangle' | 'circle')}
                  className="text-primary-green focus:ring-primary-green"
                />
                <span className="font-body text-text-gray">Rectangle</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="radio"
                  value="circle"
                  checked={shape === 'circle'}
                  onChange={(e) => setShape(e.target.value as 'rectangle' | 'circle')}
                  className="text-primary-green focus:ring-primary-green"
                />
                <span className="font-body text-text-gray">Circle</span>
              </label>
            </div>
          </div>

          {/* Dimensions */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {shape === 'rectangle' ? (
              <>
                <InputField
                  label="Length"
                  value={length}
                  onChange={setLength}
                  unit={lengthUnit}
                  onUnitChange={setLengthUnit}
                  units={['feet', 'inches']}
                />
                <InputField
                  label="Width"
                  value={width}
                  onChange={setWidth}
                  unit={widthUnit}
                  onUnitChange={setWidthUnit}
                  units={['feet', 'inches']}
                />
              </>
            ) : (
              <InputField
                label="Diameter"
                value={diameter}
                onChange={setDiameter}
                unit={diameterUnit}
                onUnitChange={setDiameterUnit}
                units={['feet', 'inches']}
              />
            )}
            <InputField
              label="Depth"
              value={depth}
              onChange={setDepth}
              unit={depthUnit}
              onUnitChange={setDepthUnit}
              units={['inches', 'cm']}
            />
          </div>
        </div>
      </div>

      {/* Results */}
      {results && (
        <ResultsCard title="Volume Calculation Results">
          <div className="space-y-3">
            <div className="text-lg">
              <span className="font-body font-semibold text-text-dark">Total Volume: </span>
              <span className="font-body text-success-green font-semibold">
                {results.cubicFeet} cubic feet
              </span>
            </div>
            <div className="text-lg">
              <span className="font-body font-semibold text-text-dark">Total Volume: </span>
              <span className="font-body text-success-green font-semibold">
                {results.cubicYards} cubic yards
              </span>
            </div>
            
            <div className="border-t pt-4 mt-4">
              <p className="font-body font-semibold text-text-dark mb-3">You will need approximately:</p>
              <ul className="space-y-2">
                <li className="flex justify-between items-center">
                  <span className="font-body text-text-gray">{results.bags2CuFt} bags of soil (2 cu ft bags)</span>
                </li>
                <li className="flex justify-between items-center">
                  <span className="font-body text-text-gray">{results.bags075CuFt} bags of soil (0.75 cu ft bags)</span>
                </li>
              </ul>
            </div>
          </div>
        </ResultsCard>
      )}
    </div>
  );
};

export default SoilCalculator;