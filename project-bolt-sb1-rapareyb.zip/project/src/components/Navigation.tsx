import React from 'react';
import { Calculator, Scaling as Seedling, Zap } from 'lucide-react';
import type { CalculatorType } from '../App';

interface NavigationProps {
  activeCalculator: CalculatorType;
  setActiveCalculator: (calculator: CalculatorType) => void;
}

const Navigation: React.FC<NavigationProps> = ({ activeCalculator, setActiveCalculator }) => {
  const navItems = [
    { id: 'soil' as CalculatorType, label: 'Soil & Mulch', icon: Calculator },
    { id: 'seed' as CalculatorType, label: 'Seed Planner', icon: Seedling },
    { id: 'fertilizer' as CalculatorType, label: 'Fertilizer', icon: Zap },
  ];

  return (
    <nav className="bg-white border-b-2 border-secondary-green/20">
      <div className="container mx-auto px-4">
        <div className="flex justify-center">
          <div className="flex gap-1 md:gap-2">
            {navItems.map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setActiveCalculator(id)}
                className={`flex items-center gap-2 px-4 md:px-6 py-4 font-body font-semibold transition-all duration-200 transform hover:scale-105 ${
                  activeCalculator === id
                    ? 'bg-primary-green text-white border-b-4 border-primary-green'
                    : 'text-text-gray hover:text-primary-green hover:bg-secondary-green/10'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="hidden sm:inline">{label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;