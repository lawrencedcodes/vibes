import React, { useState, useEffect } from 'react';
import { Zap } from 'lucide-react';
import InputField from './InputField';
import ResultsCard from './ResultsCard';

const fertilizerData = {
  'All-Purpose 10-10-10': { rate_lbs_1000_sqft: 2, unit: 'lbs' },
  'Blood Meal 12-0-0': { rate_lbs_1000_sqft: 1.5, unit: 'lbs' },
  'Bone Meal 4-12-0': { rate_lbs_1000_sqft: 3, unit: 'lbs' },
  'Organic Compost': { rate_lbs_1000_sqft: 25, unit: 'lbs' }
};

const FertilizerCalculator: React.FC = () => {
  const [area, setArea] = useState<string>('');
  const [areaUnit, setAreaUnit] = useState<'sq ft' | 'sq meters'>('sq ft');
  const [fertilizerType, setFertilizerType] = useState<string>('');
  const [results, setResults] = useState<any>(null);

  const calculateFertilizer = () => {
    if (!fertilizerType) return null;

    let areaInSqFt = parseFloat(area);
    if (areaUnit === 'sq meters') {
      areaInSqFt = parseFloat(area) * 10.764; // Convert to sq ft
    }

    const fertilizer = fertilizerData[fertilizerType as keyof typeof fertilizerData];
    const totalAmount = (areaInSqFt / 1000) * fertilizer.rate_lbs_1000_sqft;

    return {
      area: parseFloat(area),
      areaUnit,
      fertilizerName: fertilizerType,
      amount: totalAmount.toFixed(1),
      unit: fertilizer.unit,
    };
  };

  useEffect(() => {
    const allInputsValid = () => {
      return area && fertilizerType && 
             !isNaN(parseFloat(area)) &&
             parseFloat(area) > 0;
    };

    if (allInputsValid()) {
      setResults(calculateFertilizer());
    } else {
      setResults(null);
    }
  }, [area, areaUnit, fertilizerType]);

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-md p-6">
        <div className="flex items-center gap-3 mb-6">
          <Zap className="w-6 h-6 text-primary-green" />
          <h2 className="text-2xl font-heading font-semibold text-text-dark">
            Fertilizer Estimator
          </h2>
        </div>

        <div className="space-y-6">
          {/* Garden Area */}
          <InputField
            label="Garden Area"
            value={area}
            onChange={setArea}
            unit={areaUnit}
            onUnitChange={setAreaUnit}
            units={['sq ft', 'sq meters']}
          />

          {/* Fertilizer Type */}
          <div>
            <label className="block text-sm font-body font-semibold text-text-gray mb-2">
              Fertilizer Type:
            </label>
            <select
              value={fertilizerType}
              onChange={(e) => setFertilizerType(e.target.value)}
              className="w-full px-4 py-2 border border-secondary-green rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-green focus:border-primary-green font-body"
            >
              <option value="">Select fertilizer type...</option>
              {Object.keys(fertilizerData).map((fertilizer) => (
                <option key={fertilizer} value={fertilizer}>
                  {fertilizer}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Results */}
      {results && (
        <ResultsCard title="Fertilizer Requirements">
          <div className="text-center space-y-4">
            <p className="font-body text-text-gray">
              For your <span className="font-semibold">{results.area} {results.areaUnit}</span> garden, you will need:
            </p>
            
            <div className="bg-success-green/10 rounded-lg p-6">
              <div className="text-4xl font-heading font-semibold text-success-green mb-2">
                {results.amount} {results.unit}
              </div>
              <div className="text-lg font-body font-semibold text-text-dark">
                of {results.fertilizerName}
              </div>
            </div>

            <div className="bg-secondary-green/10 rounded-lg p-4">
              <p className="font-body text-sm text-text-gray">
                This calculation is based on standard application rates. Always follow package instructions and consider soil test results for best results.
              </p>
            </div>
          </div>
        </ResultsCard>
      )}
    </div>
  );
};

export default FertilizerCalculator;