import React, { useState, useEffect } from 'react';
import { Scaling as Seedling } from 'lucide-react';
import InputField from './InputField';
import ResultsCard from './ResultsCard';

const plantData = {
  'Carrot': { spacing: 3, notes: 'Plant in rows 1 foot apart.' },
  'Tomato (Bush)': { spacing: 24, notes: 'Give each plant ample space.' },
  'Lettuce (Head)': { spacing: 12, notes: 'Space evenly for full heads.' },
  'Radish': { spacing: 2, notes: 'Quick growing, can be inter-planted.' },
  'Spinach': { spacing: 6, notes: 'Plant in early spring or fall.' },
  'Basil': { spacing: 10, notes: 'Loves sun, prune for bushier growth.' },
  'Rosemary': { spacing: 24, notes: 'Perennial, needs well-drained soil.' },
  'Bell Pepper': { spacing: 18, notes: 'Requires a long, warm growing season.' },
  'Cucumber (Bush)': { spacing: 36, notes: 'Provide support for vines if needed.' }
};

const SeedPlanner: React.FC = () => {
  const [selectedPlant, setSelectedPlant] = useState<string>('');
  const [length, setLength] = useState<string>('');
  const [width, setWidth] = useState<string>('');
  const [results, setResults] = useState<any>(null);

  const calculatePlants = () => {
    if (!selectedPlant) return null;

    const lengthInches = parseFloat(length) * 12;
    const widthInches = parseFloat(width) * 12;
    const gardenArea = lengthInches * widthInches;
    
    const plant = plantData[selectedPlant as keyof typeof plantData];
    const plantArea = plant.spacing * plant.spacing;
    const numberOfPlants = Math.floor(gardenArea / plantArea);

    return {
      numberOfPlants,
      plantName: selectedPlant,
      notes: plant.notes,
      length: parseFloat(length),
      width: parseFloat(width),
    };
  };

  useEffect(() => {
    const allInputsValid = () => {
      return selectedPlant && length && width && 
             !isNaN(parseFloat(length)) && 
             !isNaN(parseFloat(width)) &&
             parseFloat(length) > 0 &&
             parseFloat(width) > 0;
    };

    if (allInputsValid()) {
      setResults(calculatePlants());
    } else {
      setResults(null);
    }
  }, [selectedPlant, length, width]);

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-md p-6">
        <div className="flex items-center gap-3 mb-6">
          <Seedling className="w-6 h-6 text-primary-green" />
          <h2 className="text-2xl font-heading font-semibold text-text-dark">
            Garden Bed Seed Planner
          </h2>
        </div>

        <div className="space-y-6">
          {/* Plant Selection */}
          <div>
            <label className="block text-sm font-body font-semibold text-text-gray mb-2">
              Choose a Plant:
            </label>
            <select
              value={selectedPlant}
              onChange={(e) => setSelectedPlant(e.target.value)}
              className="w-full px-4 py-2 border border-secondary-green rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-green focus:border-primary-green font-body"
            >
              <option value="">Select a plant...</option>
              {Object.keys(plantData).map((plant) => (
                <option key={plant} value={plant}>
                  {plant}
                </option>
              ))}
            </select>
          </div>

          {/* Garden Dimensions */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <InputField
              label="Garden Bed Length"
              value={length}
              onChange={setLength}
              unit="feet"
              fixedUnit={true}
            />
            <InputField
              label="Garden Bed Width"
              value={width}
              onChange={setWidth}
              unit="feet"
              fixedUnit={true}
            />
          </div>
        </div>
      </div>

      {/* Results */}
      {results && (
        <ResultsCard title="Planting Recommendations">
          <div className="text-center space-y-4">
            <p className="font-body text-text-gray">
              For a <span className="font-semibold">{results.length} ft × {results.width} ft</span> bed, you can plant:
            </p>
            
            <div className="bg-success-green/10 rounded-lg p-6">
              <div className="text-6xl font-heading font-semibold text-success-green mb-2">
                {results.numberOfPlants}
              </div>
              <div className="text-xl font-body font-semibold text-text-dark">
                {results.plantName} plants
              </div>
            </div>

            <div className="bg-secondary-green/10 rounded-lg p-4">
              <p className="font-body font-semibold text-text-dark mb-2">Planting Notes:</p>
              <p className="font-body text-text-gray">{results.notes}</p>
            </div>
          </div>
        </ResultsCard>
      )}
    </div>
  );
};

export default SeedPlanner;