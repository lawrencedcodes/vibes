import React from 'react';
import { Leaf } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-primary-green text-white py-8 mt-16">
      <div className="container mx-auto px-4 text-center">
        <div className="flex items-center justify-center gap-2 mb-4">
          <Leaf className="w-5 h-5" />
          <span className="font-body text-sm">Growing gardens, one calculation at a time</span>
        </div>
        
        <div className="space-y-2 text-sm font-body">
          <p>© 2025 The Verdant Garden Calculator. All Rights Reserved.</p>
          <p className="text-secondary-green">
            As an Amazon Associate and member of other affiliate programs, I earn from qualifying purchases.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;