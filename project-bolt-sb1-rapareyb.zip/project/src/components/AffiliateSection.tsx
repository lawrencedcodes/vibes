import React from 'react';
import { ExternalLink, Star } from 'lucide-react';

const affiliateProducts = [
  {
    name: "Premium Garden Soil Mix",
    description: "Nutrient-rich, organic soil blend perfect for vegetables and flowers. Pre-mixed with compost and perlite for optimal drainage.",
    image: "https://placehold.co/300x200/A3B8A1/ffffff?text=Garden+Soil",
    rating: 4.8,
  },
  {
    name: "Professional Seed Starting Kit",
    description: "Complete starter set with biodegradable pots, seed starting mix, and plant markers. Everything you need to start your garden indoors.",
    image: "https://placehold.co/300x200/3D553A/ffffff?text=Seed+Kit",
    rating: 4.9,
  },
  {
    name: "Organic All-Purpose Fertilizer",
    description: "Slow-release organic granules provide balanced nutrition for all garden plants. Safe for vegetables and promotes healthy soil biology.",
    image: "https://placehold.co/300x200/8A6F5E/ffffff?text=Fertilizer",
    rating: 4.7,
  },
  {
    name: "Garden Planning Journal",
    description: "Beautifully designed planner to track your garden progress, plan layouts, and record harvest dates. Includes planting calendar and tips.",
    image: "https://placehold.co/300x200/4CAF50/ffffff?text=Journal",
    rating: 4.6,
  },
];

const AffiliateSection: React.FC = () => {
  return (
    <section className="mt-16">
      <div className="text-center mb-10">
        <h2 className="text-3xl font-heading font-semibold text-text-dark mb-4">
          Recommended Gardening Tools & Supplies
        </h2>
        <p className="text-lg font-body text-text-gray max-w-2xl mx-auto">
          Hand-picked products to help you succeed with your garden projects. Quality tools and supplies make all the difference.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {affiliateProducts.map((product, index) => (
          <div key={index} className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
            <div className="relative">
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-48 object-cover"
              />
              <div className="absolute top-3 right-3 bg-white/90 rounded-full px-2 py-1 flex items-center gap-1">
                <Star className="w-4 h-4 text-yellow-500 fill-current" />
                <span className="text-sm font-body font-semibold">{product.rating}</span>
              </div>
            </div>
            
            <div className="p-5">
              <h3 className="text-lg font-heading font-semibold text-text-dark mb-2">
                {product.name}
              </h3>
              <p className="text-sm font-body text-text-gray mb-4 line-clamp-3">
                {product.description}
              </p>
              
              <a
                href="#"
                className="inline-flex items-center gap-2 bg-primary-green text-white px-4 py-2 rounded-lg font-body font-semibold hover:bg-secondary-green transition-colors duration-200 transform hover:scale-105 w-full justify-center"
              >
                Check Price
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default AffiliateSection;