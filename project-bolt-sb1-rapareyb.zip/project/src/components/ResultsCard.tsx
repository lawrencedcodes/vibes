import React from 'react';
import { CheckCircle } from 'lucide-react';

interface ResultsCardProps {
  title: string;
  children: React.ReactNode;
}

const ResultsCard: React.FC<ResultsCardProps> = ({ title, children }) => {
  return (
    <div className="bg-white rounded-xl shadow-md border-l-4 border-success-green p-6 animate-fade-in">
      <div className="flex items-center gap-3 mb-4">
        <CheckCircle className="w-6 h-6 text-success-green" />
        <h3 className="text-xl font-heading font-semibold text-text-dark">
          {title}
        </h3>
      </div>
      {children}
    </div>
  );
};

export default ResultsCard;