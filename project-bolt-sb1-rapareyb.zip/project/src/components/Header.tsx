import React from 'react';
import { Sprout } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-primary-green text-white py-6">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-center gap-3">
          <Sprout className="w-8 h-8" />
          <h1 className="text-3xl md:text-4xl font-heading font-semibold">
            The Verdant Garden Calculator
          </h1>
        </div>
      </div>
    </header>
  );
};

export default Header;