<?php
// MOCK DATABASE - The Local Legend Ledger for Olive Branch, MS
$legends_data = [
    [
        'id' => 1,
        'title' => 'The Naming of Olive Branch',
        'type' => 'History',
        'latitude' => 34.9615,
        'longitude' => -89.8284,
        'short_description' => 'How the town got its name from "Cowpens" to a symbol of peace.',
        'full_story' => "Formerly known as 'Cowpens' and 'Watson\'s Crossroads', the town was given its modern name in 1846. Frances Wilson Blocker, a founder's descendant, suggested 'Olive Branch' to symbolize the dove from Noah's Ark, representing peace and a new beginning. The name was chosen for the first post office and has defined the community ever since.",
        'pro_content' => "View a digitized copy of the 1847 postal record and see the original Blocker family land deed purchased from Chickasaw Chief Lush-Pun-Tubby."
    ],
    [
        'id' => 2,
        'title' => 'The Ghost of Stuckey\'s Bridge',
        'type' => 'Legend',
        'latitude' => 32.3332,
        'longitude' => -88.4845,
        'short_description' => 'A gruesome tale of a murderous innkeeper who haunts the Chunky River.',
        'full_story' => "Though south of Olive Branch, this Mississippi legend is famous statewide. The story goes that a man named Stuckey ran an inn where he would rob and murder travelers, burying them along the riverbank. He was eventually caught and hanged from the very bridge that now bears his name. Locals and paranormal investigators report seeing his ghostly apparition carrying a lantern, searching the riverbanks, forever tied to his grisly crimes.",
        'pro_content' => "Listen to an audio narration of the full legend, including three recorded eyewitness accounts from the 1970s. Also, get the exact coordinates for the best (and safest) viewing spots."
    ],
    [
        'id' => 3,
        'title' => 'Brussel\'s Bonsai Nursery',
        'type' => 'Hidden Gem',
        'latitude' => 34.9332,
        'longitude' => -89.7218,
        'short_description' => 'The largest Bonsai nursery in the United States is hidden right here.',
        'full_story' => "Tucked away in Olive Branch is Brussel's Bonsai, a world-renowned nursery with over 175,000 square feet of greenhouse space dedicated to the ancient art of Bonsai. It was started in 1973 by Brussel Martin and has grown into a destination for enthusiasts from all over the world, hosting international masters for workshops and events.",
        'pro_content' => "Get a self-guided walking tour map of the nursery's most famous and oldest trees, including a Japanese Black Pine started in the 19th century."
    ],
    [
        'id' => 4,
        'title' => 'Holiday Inn University',
        'type' => 'History',
        'latitude' => 34.9667,
        'longitude' => -89.7925,
        'short_description' => 'The site of the world\'s first corporate university, a revolution in hospitality.',
        'full_story' => "In 1971, the Holiday Inn corporation, founded just down the road in Memphis, chose Olive Branch as the home for its groundbreaking 'Holiday Inn University.' This facility became the global training center for the entire hotel chain, standardizing service and operations worldwide. It was the first 'corporate university' of its kind and set a new standard for employee training in the hospitality industry.",
        'pro_content' => "View archived photos from the 1972 opening ceremony and see a course curriculum booklet from the first graduating class."
    ]
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Local Legend Ledger</title>
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Crimson+Text:wght@400;600&display=swap" rel="stylesheet">
    
    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <!-- Leaflet CSS -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    
    <!-- Leaflet JS -->
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    
    <style>
        :root {
            --aged-paper: #F4F1E9;
            --light-paper: #FAF8F1;
            --faded-ink: #413F3D;
            --old-gold: #C0A062;
            --muted-red: #A55D55;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: var(--aged-paper);
            color: var(--faded-ink);
            font-family: 'Crimson Text', serif;
            font-size: 16px;
            line-height: 1.6;
            overflow-x: hidden;
        }

        .app-container {
            display: flex;
            height: 100vh;
            position: relative;
        }

        /* Map Container */
        .map-container {
            flex: 2;
            position: relative;
            border-right: 3px solid var(--old-gold);
            border-image: linear-gradient(to bottom, var(--old-gold), transparent) 1;
        }

        #map {
            width: 100%;
            height: 100%;
            filter: sepia(0.2) contrast(1.1);
        }

        /* Ledger Panel */
        .ledger-panel {
            flex: 1;
            background-color: var(--light-paper);
            padding: 2rem;
            overflow-y: auto;
            border-left: 1px solid rgba(192, 160, 98, 0.3);
            box-shadow: inset 5px 0 15px rgba(0, 0, 0, 0.1);
        }

        .ledger-title {
            font-family: 'Playfair Display', serif;
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--faded-ink);
            margin-bottom: 1rem;
            text-align: center;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.1);
            border-bottom: 2px solid var(--old-gold);
            padding-bottom: 1rem;
        }

        .ledger-subtitle {
            font-size: 1.1rem;
            text-align: center;
            margin-bottom: 2rem;
            color: var(--faded-ink);
            opacity: 0.8;
            font-style: italic;
        }

        /* Legend Cards */
        .legend-card {
            background: var(--aged-paper);
            border: 2px solid rgba(192, 160, 98, 0.4);
            border-radius: 8px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            position: relative;
            overflow: hidden;
        }

        .legend-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(192, 160, 98, 0.1), transparent);
            transition: left 0.5s ease;
        }

        .legend-card:hover::before {
            left: 100%;
        }

        .legend-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
            border-color: var(--old-gold);
        }

        .legend-card.active {
            border-color: var(--old-gold);
            background-color: var(--light-paper);
            box-shadow: 0 0 20px rgba(192, 160, 98, 0.3);
        }

        .legend-type {
            display: inline-block;
            background: var(--old-gold);
            color: var(--aged-paper);
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .legend-title {
            font-family: 'Playfair Display', serif;
            font-size: 1.4rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            color: var(--faded-ink);
            line-height: 1.3;
        }

        .legend-description {
            font-size: 1rem;
            color: rgba(65, 63, 61, 0.9);
            line-height: 1.5;
        }

        /* Modal Styles */
        .modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            z-index: 1000;
            backdrop-filter: blur(3px);
        }

        .modal-content {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: var(--light-paper);
            width: 90%;
            max-width: 700px;
            max-height: 80vh;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
            border: 3px solid var(--old-gold);
        }

        .modal-header {
            background: var(--aged-paper);
            padding: 2rem;
            border-bottom: 2px solid var(--old-gold);
            position: relative;
        }

        .modal-close {
            position: absolute;
            top: 1rem;
            right: 1rem;
            background: none;
            border: none;
            font-size: 2rem;
            color: var(--faded-ink);
            cursor: pointer;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background-color 0.3s ease;
        }

        .modal-close:hover {
            background-color: rgba(192, 160, 98, 0.2);
        }

        .modal-title {
            font-family: 'Playfair Display', serif;
            font-size: 2rem;
            font-weight: 700;
            color: var(--faded-ink);
            margin-bottom: 0.5rem;
            line-height: 1.3;
        }

        .modal-body {
            padding: 2rem;
            overflow-y: auto;
            max-height: 50vh;
        }

        .modal-story {
            font-size: 1.1rem;
            line-height: 1.7;
            margin-bottom: 2rem;
            color: var(--faded-ink);
        }

        .pro-content-preview {
            position: relative;
            background: var(--aged-paper);
            border: 2px solid var(--muted-red);
            border-radius: 8px;
            padding: 2rem;
            text-align: center;
            overflow: hidden;
        }

        .blurred-content {
            filter: blur(3px);
            color: rgba(65, 63, 61, 0.6);
            font-size: 0.9rem;
            margin-bottom: 1rem;
            user-select: none;
            pointer-events: none;
        }

        .pro-cta {
            background: var(--muted-red);
            color: var(--light-paper);
            padding: 1rem 2rem;
            border-radius: 8px;
            border: none;
            font-family: 'Playfair Display', serif;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 12px rgba(165, 93, 85, 0.3);
        }

        .pro-cta:hover {
            background: #8B4F49;
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(165, 93, 85, 0.4);
        }

        .pro-star {
            font-size: 1.5rem;
            margin-right: 0.5rem;
            color: var(--old-gold);
        }

        /* Custom Leaflet Styles */
        .leaflet-popup-content-wrapper {
            background: var(--light-paper);
            border: 2px solid var(--old-gold);
            border-radius: 8px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
        }

        .leaflet-popup-content {
            font-family: 'Crimson Text', serif;
            color: var(--faded-ink);
            font-size: 1rem;
            line-height: 1.5;
        }

        .leaflet-popup-tip {
            background: var(--light-paper);
            border: 2px solid var(--old-gold);
            border-top: none;
            border-right: none;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .app-container {
                flex-direction: column;
            }

            .map-container {
                flex: 1;
                border-right: none;
                border-bottom: 3px solid var(--old-gold);
            }

            .ledger-panel {
                flex: 1;
                border-left: none;
                box-shadow: none;
                padding: 1rem;
            }

            .ledger-title {
                font-size: 2rem;
            }

            .modal-content {
                width: 95%;
                margin: 1rem;
            }

            .modal-header {
                padding: 1.5rem;
            }

            .modal-body {
                padding: 1.5rem;
            }
        }

        /* Loading Animation */
        .loading {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 1000;
            color: var(--old-gold);
            font-size: 1.2rem;
            font-family: 'Playfair Display', serif;
        }

        .loading::after {
            content: '';
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid var(--old-gold);
            border-top: 3px solid transparent;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-left: 10px;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="app-container">
        <!-- Map Container -->
        <div class="map-container">
            <div id="map"></div>
            <div class="loading" id="mapLoading">Loading Map...</div>
        </div>

        <!-- Ledger Panel -->
        <div class="ledger-panel">
            <h1 class="ledger-title">The Local Legend Ledger</h1>
            <p class="ledger-subtitle">Discovering the Hidden Stories of Olive Branch</p>
            
            <div class="legends-list">
                <?php foreach ($legends_data as $legend): ?>
                    <div class="legend-card" 
                         data-id="<?php echo $legend['id']; ?>" 
                         data-lat="<?php echo $legend['latitude']; ?>" 
                         data-lng="<?php echo $legend['longitude']; ?>">
                        <div class="legend-type"><?php echo htmlspecialchars($legend['type']); ?></div>
                        <h3 class="legend-title"><?php echo htmlspecialchars($legend['title']); ?></h3>
                        <p class="legend-description"><?php echo htmlspecialchars($legend['short_description']); ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal-overlay" id="legendModal">
        <div class="modal-content">
            <div class="modal-header">
                <button class="modal-close" id="modalClose">&times;</button>
                <h2 class="modal-title" id="modalTitle"></h2>
                <div class="legend-type" id="modalType"></div>
            </div>
            <div class="modal-body">
                <div class="modal-story" id="modalStory"></div>
                <div class="pro-content-preview">
                    <div class="blurred-content" id="modalProContent">
                        This is where the premium content would appear with detailed historical documentation, exclusive photos, and enhanced interactive features...
                    </div>
                    <button class="pro-cta">
                        <span class="pro-star">⭐</span>
                        This is a Pro Legend. Unlock detailed walking tours, historical photos, audio guides, and user-submitted stories for just $5/month. Unlock Now
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            // Initialize map
            const map = L.map('map').setView([34.96, -89.82], 11);
            
            // Use CartoDB Positron for vintage look
            L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', {
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
                subdomains: 'abcd',
                maxZoom: 19
            }).addTo(map);

            // Remove loading indicator
            $('#mapLoading').fadeOut();

            // Legend data from PHP
            const legends = <?php echo json_encode($legends_data); ?>;
            const markers = {};

            // Create custom icons
            const iconTypes = {
                'History': '<i class="fas fa-scroll" style="color: #8B4513;"></i>',
                'Legend': '<i class="fas fa-ghost" style="color: #4B0082;"></i>',
                'Hidden Gem': '<i class="fas fa-gem" style="color: #2E8B57;"></i>'
            };

            // Add markers to map
            legends.forEach(function(legend) {
                const customIcon = L.divIcon({
                    html: `<div style="background: var(--light-paper); border: 2px solid var(--old-gold); border-radius: 50%; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; box-shadow: 0 2px 8px rgba(0,0,0,0.2);">${iconTypes[legend.type] || '<i class="fas fa-map-marker-alt"></i>'}</div>`,
                    className: 'custom-div-icon',
                    iconSize: [40, 40],
                    iconAnchor: [20, 20],
                    popupAnchor: [0, -20]
                });

                const marker = L.marker([legend.latitude, legend.longitude], {
                    icon: customIcon
                }).addTo(map);

                marker.bindPopup(`
                    <div style="font-family: 'Crimson Text', serif;">
                        <strong style="font-family: 'Playfair Display', serif; color: var(--faded-ink);">${legend.title}</strong><br>
                        <small style="color: var(--old-gold); font-weight: 600;">${legend.type}</small>
                    </div>
                `);

                markers[legend.id] = marker;

                // Click marker to open modal
                marker.on('click', function() {
                    openModal(legend);
                    highlightCard(legend.id);
                });
            });

            // Handle legend card clicks
            $('.legend-card').on('click', function() {
                const id = parseInt($(this).data('id'));
                const lat = parseFloat($(this).data('lat'));
                const lng = parseFloat($(this).data('lng'));
                const legend = legends.find(l => l.id === id);

                // Pan to marker
                map.setView([lat, lng], 13);
                
                // Open popup
                if (markers[id]) {
                    markers[id].openPopup();
                }

                // Open modal
                openModal(legend);
                highlightCard(id);
            });

            // Modal functions
            function openModal(legend) {
                $('#modalTitle').text(legend.title);
                $('#modalType').text(legend.type);
                $('#modalStory').text(legend.full_story);
                $('#modalProContent').text(legend.pro_content);
                $('#legendModal').fadeIn(300);
            }

            function highlightCard(id) {
                $('.legend-card').removeClass('active');
                $(`.legend-card[data-id="${id}"]`).addClass('active');
            }

            // Close modal
            $('#modalClose, .modal-overlay').on('click', function(e) {
                if (e.target === this) {
                    $('#legendModal').fadeOut(300);
                    $('.legend-card').removeClass('active');
                }
            });

            // Prevent modal content clicks from closing modal
            $('.modal-content').on('click', function(e) {
                e.stopPropagation();
            });

            // Pro CTA click
            $('.pro-cta').on('click', function() {
                alert('Pro features coming soon! This would redirect to a subscription page.');
            });

            // Keyboard support
            $(document).on('keydown', function(e) {
                if (e.key === 'Escape') {
                    $('#legendModal').fadeOut(300);
                    $('.legend-card').removeClass('active');
                }
            });
        });
    </script>
</body>
</html>