import { useEffect, useRef } from 'react';
import L from 'leaflet';
import { Legend } from '../data/legends';

interface MapViewProps {
  legends: Legend[];
  onMarkerClick: (legend: Legend) => void;
  selectedLegendId: number | null;
  mapCenter: [number, number];
}

const MapView = ({ legends, onMarkerClick, selectedLegendId, mapCenter }: MapViewProps) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersRef = useRef<{ [key: number]: L.Marker }>({});

  useEffect(() => {
    if (!mapRef.current) return;

    // Clean up existing map
    if (mapInstanceRef.current) {
      mapInstanceRef.current.remove();
      mapInstanceRef.current = null;
      markersRef.current = {};
    }

    // Initialize map
    const map = L.map(mapRef.current).setView(mapCenter, 11);

    // Add vintage-style tile layer
    L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
      subdomains: 'abcd',
      maxZoom: 19
    }).addTo(map);

    mapInstanceRef.current = map;

    // Create custom icons for different legend types
    const createCustomIcon = (type: Legend['type']) => {
      const iconSymbols = {
        'History': '📜',
        'Legend': '👻',
        'Hidden Gem': '💎'
      };

      return L.divIcon({
        html: `<div style="
          background: #FAF8F1; 
          border: 2px solid #C0A062; 
          border-radius: 50%; 
          width: 40px; 
          height: 40px; 
          display: flex; 
          align-items: center; 
          justify-content: center; 
          box-shadow: 0 2px 8px rgba(0,0,0,0.2);
          font-size: 18px;
        ">${iconSymbols[type]}</div>`,
        className: 'custom-div-icon',
        iconSize: [40, 40],
        iconAnchor: [20, 20],
        popupAnchor: [0, -20]
      });
    };

    // Add markers for each legend
    legends.forEach((legend) => {
      const marker = L.marker([legend.latitude, legend.longitude], {
        icon: createCustomIcon(legend.type)
      }).addTo(map);

      marker.bindPopup(`
        <div style="font-family: 'Crimson Text', serif; min-width: 200px;">
          <strong style="font-family: 'Playfair Display', serif; color: #413F3D; font-size: 16px;">${legend.title}</strong><br>
          <small style="color: #C0A062; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">${legend.type}</small>
        </div>
      `);

      marker.on('click', () => {
        onMarkerClick(legend);
      });

      markersRef.current[legend.id] = marker;
    });

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, [legends, onMarkerClick, mapCenter]);

  // Handle selected legend changes
  useEffect(() => {
    if (selectedLegendId && markersRef.current[selectedLegendId] && mapInstanceRef.current) {
      const legend = legends.find(l => l.id === selectedLegendId);
      if (legend) {
        mapInstanceRef.current.setView([legend.latitude, legend.longitude], 13);
        markersRef.current[selectedLegendId].openPopup();
      }
    }
  }, [selectedLegendId, legends]);

  return (
    <div 
      ref={mapRef} 
      className="w-full h-full"
      style={{ filter: 'sepia(0.1) contrast(1.05)' }}
    />
  );
};

export default MapView;