import { Legend } from '../data/legends';

interface LegendCardProps {
  legend: Legend;
  isActive: boolean;
  onClick: () => void;
}

const LegendCard = ({ legend, isActive, onClick }: LegendCardProps) => {
  const typeColors = {
    'History': '#8B4513',
    'Legend': '#4B0082',
    'Hidden Gem': '#2E8B57'
  };

  return (
    <div
      className={`
        relative overflow-hidden cursor-pointer transition-all duration-300 ease-in-out
        p-6 mb-4 rounded-lg border-2 shadow-md
        hover:transform hover:-translate-y-1 hover:shadow-lg
        ${isActive 
          ? 'border-[#C0A062] bg-[#FAF8F1] shadow-[0_0_20px_rgba(192,160,98,0.3)]' 
          : 'border-[rgba(192,160,98,0.4)] bg-[#F4F1E9] hover:border-[#C0A062]'
        }
      `}
      onClick={onClick}
    >
      {/* Hover effect overlay */}
      <div className="absolute top-0 left-[-100%] w-full h-full bg-gradient-to-r from-transparent via-[rgba(192,160,98,0.1)] to-transparent transition-all duration-500 hover:left-[100%]" />
      
      <div className="relative z-10">
        <div 
          className="inline-block px-3 py-1 rounded-full text-xs font-semibold text-[#F4F1E9] mb-2 uppercase tracking-wider"
          style={{ backgroundColor: typeColors[legend.type] }}
        >
          {legend.type}
        </div>
        
        <h3 className="font-['Playfair_Display'] text-xl font-bold text-[#413F3D] mb-2 leading-tight">
          {legend.title}
        </h3>
        
        <p className="text-[rgba(65,63,61,0.9)] leading-relaxed">
          {legend.short_description}
        </p>
      </div>
    </div>
  );
};

export default LegendCard;