import { X, Star } from 'lucide-react';
import { Legend } from '../data/legends';

interface LegendModalProps {
  legend: Legend | null;
  isOpen: boolean;
  onClose: () => void;
}

const LegendModal = ({ legend, isOpen, onClose }: LegendModalProps) => {
  if (!isOpen || !legend) return null;

  const typeColors = {
    'History': '#8B4513',
    'Legend': '#4B0082',
    'Hidden Gem': '#2E8B57'
  };

  const handleOverlayClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  const handleProClick = () => {
    alert('Pro features coming soon! This would redirect to a subscription page.');
  };

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-80 z-50 flex items-center justify-center p-4"
      style={{ backdropFilter: 'blur(3px)' }}
      onClick={handleOverlayClick}
    >
      <div className="bg-[#FAF8F1] w-full max-w-2xl max-h-[80vh] rounded-xl overflow-hidden shadow-2xl border-3 border-[#C0A062]">
        {/* Header */}
        <div className="bg-[#F4F1E9] p-6 border-b-2 border-[#C0A062] relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 w-10 h-10 rounded-full flex items-center justify-center text-[#413F3D] hover:bg-[rgba(192,160,98,0.2)] transition-colors duration-300"
          >
            <X size={24} />
          </button>
          
          <div 
            className="inline-block px-3 py-1 rounded-full text-xs font-semibold text-[#F4F1E9] mb-3 uppercase tracking-wider"
            style={{ backgroundColor: typeColors[legend.type] }}
          >
            {legend.type}
          </div>
          
          <h2 className="font-['Playfair_Display'] text-2xl font-bold text-[#413F3D] leading-tight pr-12">
            {legend.title}
          </h2>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto max-h-[50vh]">
          <div className="text-[#413F3D] text-lg leading-relaxed mb-6">
            {legend.full_story}
          </div>

          {/* Pro Content Preview */}
          <div className="bg-[#F4F1E9] border-2 border-[#A55D55] rounded-lg p-6 text-center relative overflow-hidden">
            <div 
              className="text-[rgba(65,63,61,0.6)] text-sm mb-4 select-none pointer-events-none"
              style={{ filter: 'blur(3px)' }}
            >
              {legend.pro_content}
            </div>
            
            <button
              onClick={handleProClick}
              className="bg-[#A55D55] text-[#FAF8F1] px-6 py-3 rounded-lg border-none font-['Playfair_Display'] text-lg font-semibold cursor-pointer transition-all duration-300 hover:bg-[#8B4F49] hover:transform hover:-translate-y-1 shadow-lg hover:shadow-xl flex items-center justify-center gap-2 mx-auto"
            >
              <Star size={20} className="text-[#C0A062]" fill="currentColor" />
              This is a Pro Legend. Unlock detailed walking tours, historical photos, audio guides, and user-submitted stories for just $5/month. Unlock Now
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LegendModal;