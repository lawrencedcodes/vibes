import { useState } from 'react';
import { MapPin, Search } from 'lucide-react';

interface CitySelectorProps {
  onCityChange: (cityName: string, coordinates: [number, number]) => void;
  currentCity: string;
}

const CitySelector = ({ onCityChange, currentCity }: CitySelectorProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Predefined cities with their coordinates
  const predefinedCities = [
    { name: 'Olive Branch, MS', coordinates: [34.96, -89.82] as [number, number] },
    { name: 'Memphis, TN', coordinates: [35.1495, -90.0490] as [number, number] },
    { name: 'Nashville, TN', coordinates: [36.1627, -86.7816] as [number, number] },
    { name: 'New Orleans, LA', coordinates: [29.9511, -90.0715] as [number, number] },
    { name: 'Atlanta, GA', coordinates: [33.7490, -84.3880] as [number, number] },
    { name: 'Charleston, SC', coordinates: [32.7765, -79.9311] as [number, number] },
    { name: 'Savannah, GA', coordinates: [32.0835, -81.0998] as [number, number] },
    { name: 'Birmingham, AL', coordinates: [33.5186, -86.8104] as [number, number] },
  ];

  const handleCitySearch = async () => {
    if (!searchTerm.trim()) return;
    
    setIsLoading(true);
    try {
      // Use Nominatim (OpenStreetMap) geocoding service
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(searchTerm)}&limit=1`
      );
      const data = await response.json();
      
      if (data && data.length > 0) {
        const result = data[0];
        const coordinates: [number, number] = [parseFloat(result.lat), parseFloat(result.lon)];
        onCityChange(result.display_name, coordinates);
        setIsOpen(false);
        setSearchTerm('');
      } else {
        alert('City not found. Please try a different search term.');
      }
    } catch (error) {
      console.error('Error searching for city:', error);
      alert('Error searching for city. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handlePredefinedCitySelect = (city: { name: string; coordinates: [number, number] }) => {
    onCityChange(city.name, city.coordinates);
    setIsOpen(false);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleCitySearch();
    }
  };

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-4 py-2 bg-[#C0A062] text-[#F4F1E9] rounded-lg hover:bg-[#A68B4F] transition-colors duration-300 font-['Playfair_Display'] font-semibold shadow-md"
      >
        <MapPin size={18} />
        <span className="hidden sm:inline">{currentCity}</span>
        <span className="sm:hidden">City</span>
      </button>

      {isOpen && (
        <div className="absolute top-full left-0 mt-2 w-80 bg-[#FAF8F1] border-2 border-[#C0A062] rounded-lg shadow-xl z-50 p-4">
          <h3 className="font-['Playfair_Display'] text-lg font-bold text-[#413F3D] mb-3">
            Change Location
          </h3>
          
          {/* Search Input */}
          <div className="mb-4">
            <div className="flex gap-2">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Enter city name..."
                className="flex-1 px-3 py-2 border border-[#C0A062] rounded bg-[#F4F1E9] text-[#413F3D] placeholder-[rgba(65,63,61,0.6)] focus:outline-none focus:border-[#A55D55]"
              />
              <button
                onClick={handleCitySearch}
                disabled={isLoading || !searchTerm.trim()}
                className="px-3 py-2 bg-[#A55D55] text-[#F4F1E9] rounded hover:bg-[#8B4F49] disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-300"
              >
                {isLoading ? (
                  <div className="w-4 h-4 border-2 border-[#F4F1E9] border-t-transparent rounded-full animate-spin" />
                ) : (
                  <Search size={16} />
                )}
              </button>
            </div>
          </div>

          {/* Predefined Cities */}
          <div>
            <h4 className="text-sm font-semibold text-[#413F3D] mb-2 opacity-75">
              Popular Locations
            </h4>
            <div className="space-y-1 max-h-48 overflow-y-auto">
              {predefinedCities.map((city) => (
                <button
                  key={city.name}
                  onClick={() => handlePredefinedCitySelect(city)}
                  className="w-full text-left px-3 py-2 text-[#413F3D] hover:bg-[#F4F1E9] rounded transition-colors duration-200"
                >
                  {city.name}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-[rgba(192,160,98,0.3)]">
            <button
              onClick={() => setIsOpen(false)}
              className="w-full px-3 py-2 text-[#413F3D] hover:bg-[#F4F1E9] rounded transition-colors duration-200"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default CitySelector;