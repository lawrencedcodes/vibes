export interface Legend {
  id: number;
  title: string;
  type: 'History' | 'Legend' | 'Hidden Gem';
  latitude: number;
  longitude: number;
  short_description: string;
  full_story: string;
  pro_content: string;
}

// City-specific legend data
export const cityLegends: { [key: string]: Legend[] } = {
  'Olive Branch, MS': [
    {
      id: 1,
      title: 'The Naming of Olive Branch',
      type: 'History',
      latitude: 34.9615,
      longitude: -89.8284,
      short_description: 'How the town got its name from "Cowpens" to a symbol of peace.',
      full_story: "Formerly known as 'Cowpens' and 'Watson's Crossroads', the town was given its modern name in 1846. Frances Wilson Blocker, a founder's descendant, suggested 'Olive Branch' to symbolize the dove from Noah's Ark, representing peace and a new beginning. The name was chosen for the first post office and has defined the community ever since.",
      pro_content: "View a digitized copy of the 1847 postal record and see the original Blocker family land deed purchased from Chickasaw Chief Lush-Pun-Tubby."
    },
    {
      id: 2,
      title: 'The Ghost of Stuckey\'s Bridge',
      type: 'Legend',
      latitude: 32.3332,
      longitude: -88.4845,
      short_description: 'A gruesome tale of a murderous innkeeper who haunts the Chunky River.',
      full_story: "Though south of Olive Branch, this Mississippi legend is famous statewide. The story goes that a man named Stuckey ran an inn where he would rob and murder travelers, burying them along the riverbank. He was eventually caught and hanged from the very bridge that now bears his name. Locals and paranormal investigators report seeing his ghostly apparition carrying a lantern, searching the riverbanks, forever tied to his grisly crimes.",
      pro_content: "Listen to an audio narration of the full legend, including three recorded eyewitness accounts from the 1970s. Also, get the exact coordinates for the best (and safest) viewing spots."
    },
    {
      id: 3,
      title: 'Brussel\'s Bonsai Nursery',
      type: 'Hidden Gem',
      latitude: 34.9332,
      longitude: -89.7218,
      short_description: 'The largest Bonsai nursery in the United States is hidden right here.',
      full_story: "Tucked away in Olive Branch is Brussel's Bonsai, a world-renowned nursery with over 175,000 square feet of greenhouse space dedicated to the ancient art of Bonsai. It was started in 1973 by Brussel Martin and has grown into a destination for enthusiasts from all over the world, hosting international masters for workshops and events.",
      pro_content: "Get a self-guided walking tour map of the nursery's most famous and oldest trees, including a Japanese Black Pine started in the 19th century."
    },
    {
      id: 4,
      title: 'Holiday Inn University',
      type: 'History',
      latitude: 34.9667,
      longitude: -89.7925,
      short_description: 'The site of the world\'s first corporate university, a revolution in hospitality.',
      full_story: "In 1971, the Holiday Inn corporation, founded just down the road in Memphis, chose Olive Branch as the home for its groundbreaking 'Holiday Inn University.' This facility became the global training center for the entire hotel chain, standardizing service and operations worldwide. It was the first 'corporate university' of its kind and set a new standard for employee training in the hospitality industry.",
      pro_content: "View archived photos from the 1972 opening ceremony and see a course curriculum booklet from the first graduating class."
    }
  ],
  'Memphis, TN': [
    {
      id: 101,
      title: 'Graceland\'s Hidden Tunnels',
      type: 'Legend',
      latitude: 35.0478,
      longitude: -90.0260,
      short_description: 'Secret underground passages beneath Elvis\'s mansion.',
      full_story: "Local legends speak of a network of tunnels beneath Graceland, allegedly built by Elvis Presley for privacy and security. While never officially confirmed, former staff members have hinted at hidden passages that connected different parts of the estate, allowing the King to move unseen. Some claim these tunnels extended beyond the property, connecting to nearby buildings.",
      pro_content: "Exclusive interviews with former Graceland staff and architectural blueprints that may reveal the truth behind these mysterious passages."
    },
    {
      id: 102,
      title: 'The Orpheum Theatre Ghost',
      type: 'Legend',
      latitude: 35.1398,
      longitude: -90.0520,
      short_description: 'Mary, the friendly spirit who watches over performers.',
      full_story: "The Orpheum Theatre is home to Mary, a benevolent ghost who has been spotted in the balcony for decades. Dressed in 1920s attire, she's known to applaud good performances and has been seen by countless actors, stagehands, and audience members. Unlike most theatre ghosts, Mary is considered a good luck charm, and many performers feel honored by her presence.",
      pro_content: "Listen to recorded testimonies from Broadway stars who've encountered Mary, plus exclusive backstage photos showing unexplained phenomena."
    },
    {
      id: 103,
      title: 'Sun Studio\'s Midnight Sessions',
      type: 'History',
      latitude: 35.1459,
      longitude: -90.0564,
      short_description: 'The birthplace of rock \'n\' roll and its legendary late-night recordings.',
      full_story: "Sun Studio, where Elvis, Johnny Cash, and Jerry Lee Lewis recorded their first hits, was known for its legendary midnight sessions. Sam Phillips would often keep the studio open all night, believing that the magic happened when the sun went down. These late-night sessions produced some of the most influential recordings in music history, with artists feeding off each other's energy in spontaneous jam sessions.",
      pro_content: "Rare audio recordings from these midnight sessions, including unreleased takes and candid conversations between the legends."
    }
  ],
  'New Orleans, LA': [
    {
      id: 201,
      title: 'The LaLaurie Mansion Horrors',
      type: 'Legend',
      latitude: 29.9584,
      longitude: -90.0644,
      short_description: 'The most haunted house in America\'s dark history.',
      full_story: "The LaLaurie Mansion on Royal Street is infamous for the horrific acts committed by Madame Delphine LaLaurie in the 1830s. When a fire broke out in 1834, rescuers discovered a torture chamber in the attic where enslaved people had been subjected to unimaginable cruelty. The mansion has been plagued by paranormal activity ever since, with reports of screams, apparitions, and unexplained phenomena.",
      pro_content: "Historical documents from the 1834 investigation, architectural plans of the hidden chambers, and modern paranormal investigation footage."
    },
    {
      id: 202,
      title: 'Marie Laveau\'s Voodoo Legacy',
      type: 'History',
      latitude: 29.9625,
      longitude: -90.0634,
      short_description: 'The Voodoo Queen who ruled New Orleans\' spiritual underworld.',
      full_story: "Marie Laveau, the legendary Voodoo Queen of New Orleans, wielded immense power in 19th-century New Orleans. Known for her healing abilities, spiritual guidance, and political influence, she bridged the gap between African spiritual traditions and Catholicism. Her tomb in St. Louis Cemetery No. 1 remains one of the most visited graves in America, where people still leave offerings and make wishes.",
      pro_content: "Rare photographs of Marie Laveau, authentic voodoo artifacts from her practice, and testimonies from descendants who carry on her traditions."
    }
  ]
};

// Default to Olive Branch legends for backward compatibility
export const legendsData: Legend[] = cityLegends['Olive Branch, MS'];

// Function to get legends for a specific city
export const getLegendsForCity = (cityName: string): Legend[] => {
  return cityLegends[cityName] || [];
};

// Function to get all available cities
export const getAvailableCities = (): string[] => {
  return Object.keys(cityLegends);
};