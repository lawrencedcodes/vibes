import { useState, useEffect } from 'react';
import MapView from './components/MapView';
import LegendCard from './components/LegendCard';
import LegendModal from './components/LegendModal';
import CitySelector from './components/CitySelector';
import { Legend, getLegendsForCity, getAvailableCities } from './data/legends';

function App() {
  const [selectedLegend, setSelectedLegend] = useState<Legend | null>(null);
  const [selectedLegendId, setSelectedLegendId] = useState<number | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentCity, setCurrentCity] = useState('Olive Branch, MS');
  const [mapCenter, setMapCenter] = useState<[number, number]>([34.96, -89.82]);
  const [legends, setLegends] = useState<Legend[]>(getLegendsForCity('Olive Branch, MS'));

  const handleLegendCardClick = (legend: Legend) => {
    setSelectedLegendId(legend.id);
    setSelectedLegend(legend);
    setIsModalOpen(true);
  };

  const handleMarkerClick = (legend: Legend) => {
    setSelectedLegend(legend);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedLegend(null);
    setSelectedLegendId(null);
  };

  const handleCityChange = (cityName: string, coordinates: [number, number]) => {
    setCurrentCity(cityName);
    setMapCenter(coordinates);
    
    // Get legends for the new city
    const cityLegends = getLegendsForCity(cityName);
    setLegends(cityLegends);
    
    // Clear any selected legend
    handleCloseModal();
  };

  // Handle keyboard events
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        handleCloseModal();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <div className="flex h-screen bg-[#F4F1E9] text-[#413F3D] font-['Crimson_Text']">
      {/* Map Container */}
      <div className="flex-[2] relative border-r-3 border-[#C0A062] md:flex-[2] flex-1">
        {/* City Selector - Positioned over the map */}
        <div className="absolute top-4 left-4 z-10">
          <CitySelector 
            onCityChange={handleCityChange}
            currentCity={currentCity}
          />
        </div>
        
        <MapView 
          legends={legends}
          onMarkerClick={handleMarkerClick}
          selectedLegendId={selectedLegendId}
          mapCenter={mapCenter}
          key={currentCity} // Force re-render when city changes
        />
      </div>

      {/* Ledger Panel */}
      <div className="flex-1 bg-[#FAF8F1] p-8 overflow-y-auto border-l border-[rgba(192,160,98,0.3)] shadow-[inset_5px_0_15px_rgba(0,0,0,0.1)] md:flex-1 hidden md:block">
        <h1 className="font-['Playfair_Display'] text-4xl font-bold text-[#413F3D] mb-4 text-center border-b-2 border-[#C0A062] pb-4">
          The Local Legend Ledger
        </h1>
        
        <p className="text-lg text-center mb-8 text-[rgba(65,63,61,0.8)] italic">
          Discovering the Hidden Stories of {currentCity}
        </p>

        {legends.length > 0 ? (
          <div className="space-y-4">
            {legends.map((legend) => (
              <LegendCard
                key={legend.id}
                legend={legend}
                isActive={selectedLegendId === legend.id}
                onClick={() => handleLegendCardClick(legend)}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <div className="text-6xl mb-4 opacity-50">🗺️</div>
            <h3 className="font-['Playfair_Display'] text-xl font-bold mb-2">
              No Legends Yet
            </h3>
            <p className="text-[rgba(65,63,61,0.7)] mb-4">
              We haven't discovered any legends for {currentCity} yet.
            </p>
            <p className="text-sm text-[rgba(65,63,61,0.6)]">
              Try selecting a different city or check back later as we continue to uncover hidden stories!
            </p>
          </div>
        )}
      </div>

      {/* Mobile Legend List - Shows when no map is focused */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-[#FAF8F1] p-4 max-h-[40vh] overflow-y-auto border-t-2 border-[#C0A062]">
        <h2 className="font-['Playfair_Display'] text-xl font-bold text-center mb-4">
          Local Legends - {currentCity}
        </h2>
        {legends.length > 0 ? (
          <div className="space-y-2">
            {legends.map((legend) => (
              <div
                key={legend.id}
                className="p-3 bg-[#F4F1E9] rounded border border-[#C0A062] cursor-pointer hover:bg-[#FAF8F1]"
                onClick={() => handleLegendCardClick(legend)}
              >
                <div className="font-semibold text-sm">{legend.title}</div>
                <div className="text-xs text-[rgba(65,63,61,0.7)]">{legend.type}</div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-4">
            <p className="text-[rgba(65,63,61,0.7)]">No legends available for {currentCity}</p>
          </div>
        )}
      </div>

      {/* Modal */}
      <LegendModal
        legend={selectedLegend}
        isOpen={isModalOpen}
        onClose={handleCloseModal}
      />
    </div>
  );
}

export default App;