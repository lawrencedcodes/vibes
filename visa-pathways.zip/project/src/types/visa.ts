export interface VisaPathway {
  citizenship: string;
  destination: string;
  visa_name: string;
  visa_type: string;
  income_required_eur: number;
  income_type: string;
  avg_timeline_days: number;
  estimated_cost_usd: number;
  checklist: string[];
  notes: string;
}

export interface CountryOption {
  code: string;
  name: string;
  flag: string;
}