import { VisaPathway, CountryOption } from '../types/visa';

// MOCK DATABASE - This simulates our SQLite database
export const visaData: VisaPathway[] = [
  // USA Citizen pathways
  {
    citizenship: 'USA',
    destination: 'Portugal',
    visa_name: 'D7 Passive Income Visa',
    visa_type: 'Long-Term Residency',
    income_required_eur: 820,
    income_type: 'Passive (pensions, rent, dividends)',
    avg_timeline_days: 120,
    estimated_cost_usd: 1500,
    checklist: [
      "Obtain NIF (Portuguese Tax Number)",
      "Open Portuguese Bank Account & Deposit Funds",
      "Secure 12-Month Lease Agreement",
      "Submit Application at VFS/Consulate",
      "Attend SEF Interview in Portugal"
    ],
    notes: 'Most popular route for non-EU retirees and remote workers with passive income.'
  },
  {
    citizenship: 'USA',
    destination: 'Portugal',
    visa_name: 'Digital Nomad Visa (D8)',
    visa_type: 'Long-Term Residency',
    income_required_eur: 3280,
    income_type: 'Active Remote Work',
    avg_timeline_days: 90,
    estimated_cost_usd: 1200,
    checklist: [
      "Provide Proof of Remote Employment/Contracts for last 3 months",
      "Obtain NIF (Portuguese Tax Number)",
      "Open Portuguese Bank Account",
      "Submit Application at VFS/Consulate",
      "Attend SEF Interview in Portugal"
    ],
    notes: 'Specifically for remote workers. Higher income requirement than the D7.'
  },
  {
    citizenship: 'USA',
    destination: 'Mexico',
    visa_name: 'Temporary Resident Visa',
    visa_type: 'Long-Term Residency',
    income_required_eur: 2500,
    income_type: 'Active or Passive',
    avg_timeline_days: 45,
    estimated_cost_usd: 400,
    checklist: [
      "Schedule Appointment at Mexican Consulate in USA",
      "Show Bank Statements proving income/savings",
      "Complete application form and pay fees",
      "Receive Visa Sticker in Passport",
      "Enter Mexico and exchange for a Resident Card within 30 days"
    ],
    notes: 'Popular choice for US citizens due to proximity and lower cost of living.'
  },
  {
    citizenship: 'USA',
    destination: 'Estonia',
    visa_name: 'Digital Nomad Visa',
    visa_type: 'Temporary Residency',
    income_required_eur: 3500,
    income_type: 'Active Remote Work',
    avg_timeline_days: 30,
    estimated_cost_usd: 100,
    checklist: [
      "Prove remote employment or freelance contracts",
      "Show health insurance coverage",
      "Submit online application",
      "Receive digital visa approval",
      "Enter Estonia within 6 months"
    ],
    notes: 'One of the first and most streamlined digital nomad visas in Europe.'
  },
  {
    citizenship: 'USA',
    destination: 'Spain',
    visa_name: 'Non-Lucrative Visa',
    visa_type: 'Long-Term Residency',
    income_required_eur: 2400,
    income_type: 'Passive Income Only',
    avg_timeline_days: 90,
    estimated_cost_usd: 800,
    checklist: [
      "Prove passive income of €2,400/month",
      "Obtain Spanish health insurance",
      "Get criminal background check apostilled",
      "Submit application at Spanish consulate",
      "Attend interview and provide biometrics"
    ],
    notes: 'Cannot work in Spain but allows residency. Popular retirement visa.'
  },
  {
    citizenship: 'USA',
    destination: 'Thailand',
    visa_name: 'Long-Term Resident (LTR) Visa',
    visa_type: 'Long-Term Residency',
    income_required_eur: 7500,
    income_type: 'Active Remote Work',
    avg_timeline_days: 60,
    estimated_cost_usd: 1000,
    checklist: [
      "Prove income of $80,000+ annually",
      "Show remote work employment",
      "Get health insurance coverage",
      "Submit online application",
      "Attend embassy interview"
    ],
    notes: 'New visa for wealthy digital nomads. 10-year validity with work permission.'
  },
  {
    citizenship: 'USA',
    destination: 'Dubai',
    visa_name: 'Remote Work Visa',
    visa_type: 'Temporary Residency',
    income_required_eur: 4500,
    income_type: 'Active Remote Work',
    avg_timeline_days: 14,
    estimated_cost_usd: 600,
    checklist: [
      "Prove employment with non-UAE company",
      "Show salary of $5,000+ monthly",
      "Get health insurance",
      "Submit online application",
      "Receive Emirates ID upon arrival"
    ],
    notes: 'Tax-free income and excellent infrastructure for remote workers.'
  },
  {
    citizenship: 'USA',
    destination: 'Germany',
    visa_name: 'Freelancer Visa',
    visa_type: 'Long-Term Residency',
    income_required_eur: 2000,
    income_type: 'Freelance Income',
    avg_timeline_days: 120,
    estimated_cost_usd: 200,
    checklist: [
      "Prepare detailed business plan",
      "Show proof of freelance clients/contracts",
      "Get German health insurance",
      "Submit application at German consulate",
      "Attend interview with supporting documents"
    ],
    notes: 'For freelancers and consultants. Requires proving economic benefit to Germany.'
  },
  {
    citizenship: 'USA',
    destination: 'Italy',
    visa_name: 'Self-Employment Visa',
    visa_type: 'Long-Term Residency',
    income_required_eur: 8500,
    income_type: 'Investment/Business',
    avg_timeline_days: 180,
    estimated_cost_usd: 1200,
    checklist: [
      "Invest €500,000 in Italian company",
      "Prepare detailed business plan",
      "Get Italian health insurance",
      "Submit application at Italian consulate",
      "Attend multiple interviews and inspections"
    ],
    notes: 'High investment requirement but leads to EU residency and eventual citizenship.'
  },
  {
    citizenship: 'USA',
    destination: 'Netherlands',
    visa_name: 'DAFT Treaty Visa',
    visa_type: 'Long-Term Residency',
    income_required_eur: 4500,
    income_type: 'Business Investment',
    avg_timeline_days: 90,
    estimated_cost_usd: 800,
    checklist: [
      "Invest €4,500 in Dutch business",
      "Register business with Dutch Chamber of Commerce",
      "Get Dutch health insurance",
      "Submit residence permit application",
      "Attend IND appointment"
    ],
    notes: 'Special treaty between USA and Netherlands. Renewable indefinitely.'
  },

  // Canadian Citizen pathways
  {
    citizenship: 'Canada',
    destination: 'Mexico',
    visa_name: 'Temporary Resident Visa',
    visa_type: 'Long-Term Residency',
    income_required_eur: 2500,
    income_type: 'Active or Passive',
    avg_timeline_days: 30,
    estimated_cost_usd: 300,
    checklist: [
      "Schedule Appointment at Mexican Consulate in Canada",
      "Show Bank Statements proving income/savings",
      "Receive Visa Sticker in Passport",
      "Enter Mexico and exchange for a Resident Card within 30 days"
    ],
    notes: 'Very straightforward process if you meet the financial requirements.'
  },
  {
    citizenship: 'Canada',
    destination: 'Portugal',
    visa_name: 'D7 Passive Income Visa',
    visa_type: 'Long-Term Residency',
    income_required_eur: 820,
    income_type: 'Passive (pensions, rent, dividends)',
    avg_timeline_days: 100,
    estimated_cost_usd: 1400,
    checklist: [
      "Obtain NIF (Portuguese Tax Number)",
      "Open Portuguese Bank Account & Deposit Funds",
      "Secure 12-Month Lease Agreement",
      "Submit Application at Portuguese Consulate in Canada",
      "Attend SEF Interview in Portugal"
    ],
    notes: 'Same visa as for US citizens, but processed through Canadian consulates.'
  },
  {
    citizenship: 'Canada',
    destination: 'Estonia',
    visa_name: 'Digital Nomad Visa',
    visa_type: 'Temporary Residency',
    income_required_eur: 3500,
    income_type: 'Active Remote Work',
    avg_timeline_days: 30,
    estimated_cost_usd: 100,
    checklist: [
      "Prove remote employment or freelance contracts",
      "Show health insurance coverage",
      "Submit online application",
      "Receive digital visa approval",
      "Enter Estonia within 6 months"
    ],
    notes: 'Digital-first application process. Very nomad-friendly.'
  },
  {
    citizenship: 'Canada',
    destination: 'Japan',
    visa_name: 'Working Holiday Visa',
    visa_type: 'Temporary Residency',
    income_required_eur: 2000,
    income_type: 'Savings/Income Proof',
    avg_timeline_days: 21,
    estimated_cost_usd: 300,
    checklist: [
      "Be between 18-30 years old",
      "Show proof of funds (CAD $2,500)",
      "Get health insurance",
      "Submit application to Japanese consulate",
      "Receive visa sticker in passport"
    ],
    notes: 'Age-restricted but allows work in Japan. Very popular among young Canadians.'
  },
  {
    citizenship: 'Canada',
    destination: 'Australia',
    visa_name: 'Working Holiday Visa',
    visa_type: 'Temporary Residency',
    income_required_eur: 3500,
    income_type: 'Savings Proof',
    avg_timeline_days: 30,
    estimated_cost_usd: 400,
    checklist: [
      "Be between 18-30 years old",
      "Show proof of funds (AUD $5,000)",
      "Get health examination",
      "Submit online application",
      "Receive visa grant notification"
    ],
    notes: 'Commonwealth connection makes this easier for Canadians. Can extend to 2-3 years.'
  }
];

export const countries: CountryOption[] = [
  // Citizenship options
  { code: 'USA', name: 'United States', flag: '🇺🇸' },
  { code: 'Canada', name: 'Canada', flag: '🇨🇦' },
  
  // Destination options (20+ countries)
  { code: 'Portugal', name: 'Portugal', flag: '🇵🇹' },
  { code: 'Mexico', name: 'Mexico', flag: '🇲🇽' },
  { code: 'Estonia', name: 'Estonia', flag: '🇪🇪' },
  { code: 'Spain', name: 'Spain', flag: '🇪🇸' },
  { code: 'Thailand', name: 'Thailand', flag: '🇹🇭' },
  { code: 'Dubai', name: 'Dubai (UAE)', flag: '🇦🇪' },
  { code: 'Germany', name: 'Germany', flag: '🇩🇪' },
  { code: 'Italy', name: 'Italy', flag: '🇮🇹' },
  { code: 'Netherlands', name: 'Netherlands', flag: '🇳🇱' },
  { code: 'Japan', name: 'Japan', flag: '🇯🇵' },
  { code: 'Australia', name: 'Australia', flag: '🇦🇺' },
  { code: 'Singapore', name: 'Singapore', flag: '🇸🇬' },
  { code: 'France', name: 'France', flag: '🇫🇷' },
  { code: 'Czech Republic', name: 'Czech Republic', flag: '🇨🇿' },
  { code: 'Poland', name: 'Poland', flag: '🇵🇱' },
  { code: 'Croatia', name: 'Croatia', flag: '🇭🇷' },
  { code: 'Malta', name: 'Malta', flag: '🇲🇹' },
  { code: 'Cyprus', name: 'Cyprus', flag: '🇨🇾' },
  { code: 'Greece', name: 'Greece', flag: '🇬🇷' },
  { code: 'Romania', name: 'Romania', flag: '🇷🇴' },
  { code: 'Hungary', name: 'Hungary', flag: '🇭🇺' },
  { code: 'Latvia', name: 'Latvia', flag: '🇱🇻' },
  { code: 'Lithuania', name: 'Lithuania', flag: '🇱🇹' },
  { code: 'Slovenia', name: 'Slovenia', flag: '🇸🇮' },
  { code: 'Slovakia', name: 'Slovakia', flag: '🇸🇰' },
  { code: 'Bulgaria', name: 'Bulgaria', flag: '🇧🇬' }
];