import React from 'react';
import { VisaPathway, CountryOption } from '../types/visa';
import { PathwayCard } from './PathwayCard';

interface ResultsViewProps {
  pathways: VisaPathway[];
  countries: CountryOption[];
  citizenship: string;
  destination: string;
  onViewDetails: (pathway: VisaPathway) => void;
  onBackToSearch: () => void;
}

export const ResultsView: React.FC<ResultsViewProps> = ({
  pathways,
  countries,
  citizenship,
  destination,
  onViewDetails,
  onBackToSearch
}) => {
  const citizenshipCountry = countries.find(c => c.code === citizenship);
  const destinationCountry = countries.find(c => c.code === destination);

  return (
    <div className="min-h-screen bg-[#121212] p-4">
      <div className="max-w-4xl mx-auto">
        <button
          onClick={onBackToSearch}
          className="text-[#FF4F5A] hover:text-[#E8434E] mb-6 text-sm font-medium"
        >
          ← Back to Search
        </button>
        
        <h2 className="text-3xl md:text-4xl font-bold text-[#EAEAEA] mb-2">
          Pathways for a {citizenshipCountry?.flag} {citizenshipCountry?.name} citizen to live in {destinationCountry?.flag} {destinationCountry?.name}
        </h2>
        
        <p className="text-[#888888] mb-8">
          Found {pathways.length} visa pathway{pathways.length !== 1 ? 's' : ''} based on your criteria.
        </p>
        
        {pathways.length > 0 ? (
          <div className="grid gap-6 md:grid-cols-2">
            {pathways.map((pathway, index) => (
              <PathwayCard
                key={index}
                pathway={pathway}
                onViewDetails={onViewDetails}
              />
            ))}
          </div>
        ) : (
          <div className="bg-[#1A1A1A] border border-[#333333] p-8 rounded-lg text-center">
            <p className="text-[#888888] text-lg mb-4">
              No visa pathways found for this combination.
            </p>
            <p className="text-[#888888] text-sm">
              We're constantly adding new pathways. Check back soon or try a different destination.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};