import React from 'react';
import { CountryOption } from '../types/visa';

interface SearchFormProps {
  countries: CountryOption[];
  citizenship: string;
  destination: string;
  onCitizenshipChange: (value: string) => void;
  onDestinationChange: (value: string) => void;
  onSubmit: (e: React.FormEvent) => void;
}

export const SearchForm: React.FC<SearchFormProps> = ({
  countries,
  citizenship,
  destination,
  onCitizenshipChange,
  onDestinationChange,
  onSubmit
}) => {
  const citizenshipOptions = countries.filter(c => c.code === 'USA' || c.code === 'Canada');
  const destinationOptions = countries.filter(c => c.code !== 'USA' && c.code !== 'Canada');

  return (
    <div className="min-h-screen bg-[#121212] flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        <h1 className="text-4xl md:text-6xl font-bold text-[#EAEAEA] text-center mb-4">
          Find your path to live anywhere.
        </h1>
        
        <p className="text-[#888888] text-center mb-12 text-lg">
          Legal visa pathways for digital nomads, remote workers, and anyone seeking global freedom.
        </p>
        
        <form onSubmit={onSubmit} className="bg-[#1A1A1A] border border-[#333333] p-8 rounded-lg">
          <div className="space-y-6">
            <div>
              <label htmlFor="citizenship" className="block text-[#EAEAEA] text-sm font-medium mb-3">
                Your Citizenship
              </label>
              <select
                id="citizenship"
                value={citizenship}
                onChange={(e) => onCitizenshipChange(e.target.value)}
                className="w-full bg-[#121212] border border-[#333333] text-[#EAEAEA] p-4 rounded focus:outline-none focus:border-[#FF4F5A] text-lg"
                required
              >
                <option value="">Select your citizenship...</option>
                {citizenshipOptions.map(country => (
                  <option key={country.code} value={country.code}>
                    {country.flag} {country.name}
                  </option>
                ))}
              </select>
            </div>
            
            <div>
              <label htmlFor="destination" className="block text-[#EAEAEA] text-sm font-medium mb-3">
                Where do you want to live?
              </label>
              <select
                id="destination"
                value={destination}
                onChange={(e) => onDestinationChange(e.target.value)}
                className="w-full bg-[#121212] border border-[#333333] text-[#EAEAEA] p-4 rounded focus:outline-none focus:border-[#FF4F5A] text-lg"
                required
              >
                <option value="">Select destination...</option>
                {destinationOptions.map(country => (
                  <option key={country.code} value={country.code}>
                    {country.flag} {country.name}
                  </option>
                ))}
              </select>
            </div>
            
            <button
              type="submit"
              className="w-full bg-[#FF4F5A] hover:bg-[#E8434E] text-white font-bold py-4 px-6 rounded text-lg transition-colors"
            >
              Find Pathways
            </button>
          </div>
        </form>
        
        <p className="text-[#888888] text-center mt-8 text-sm">
          Built by indie hackers, for the globally minded.
        </p>
      </div>
    </div>
  );
};