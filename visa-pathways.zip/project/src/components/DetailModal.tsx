import React from 'react';
import { VisaPathway } from '../types/visa';
import { X } from 'lucide-react';

interface DetailModalProps {
  pathway: VisaPathway | null;
  onClose: () => void;
}

export const DetailModal: React.FC<DetailModalProps> = ({ pathway, onClose }) => {
  if (!pathway) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center p-4 z-50">
      <div className="bg-[#1A1A1A] border border-[#333333] rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-[#1A1A1A] border-b border-[#333333] p-6 flex justify-between items-start">
          <div>
            <h3 className="text-2xl font-bold text-[#EAEAEA] mb-1">{pathway.visa_name}</h3>
            <p className="text-[#888888]">{pathway.visa_type}</p>
          </div>
          <button
            onClick={onClose}
            className="text-[#888888] hover:text-[#EAEAEA] transition-colors"
          >
            <X size={24} />
          </button>
        </div>
        
        <div className="p-6">
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="bg-[#121212] p-4 rounded">
              <p className="text-[#888888] text-sm">Minimum Income</p>
              <p className="text-[#EAEAEA] font-bold">€{pathway.income_required_eur}/month</p>
              <p className="text-[#888888] text-xs">{pathway.income_type}</p>
            </div>
            <div className="bg-[#121212] p-4 rounded">
              <p className="text-[#888888] text-sm">Timeline</p>
              <p className="text-[#EAEAEA] font-bold">{pathway.avg_timeline_days} days</p>
              <p className="text-[#888888] text-xs">Average processing time</p>
            </div>
          </div>
          
          <div className="mb-6">
            <p className="text-[#888888] text-sm mb-2">Estimated Total Cost</p>
            <p className="text-[#EAEAEA] text-2xl font-bold">${pathway.estimated_cost_usd}</p>
          </div>
          
          <div className="mb-6">
            <h4 className="text-[#EAEAEA] font-bold mb-3">Step-by-Step Checklist</h4>
            <ol className="space-y-3">
              {pathway.checklist.map((step, index) => (
                <li key={index} className="flex items-start">
                  <span className="bg-[#FF4F5A] text-white text-xs font-bold rounded-full w-6 h-6 flex items-center justify-center mr-3 mt-0.5 flex-shrink-0">
                    {index + 1}
                  </span>
                  <span className={`text-[#EAEAEA] ${index >= 3 ? 'blur-sm' : ''}`}>
                    {step}
                  </span>
                </li>
              ))}
              
              {pathway.checklist.length > 3 && (
                <div className="bg-[#121212] border border-[#FF4F5A] p-4 rounded-lg text-center mt-4">
                  <p className="text-[#FF4F5A] font-bold mb-2">⭐️ Unlock all steps, document templates, and community tips with VisaPath Pro</p>
                  <button className="bg-[#FF4F5A] hover:bg-[#E8434E] text-white font-bold py-2 px-6 rounded text-sm transition-colors">
                    Upgrade to Pro - $29/month
                  </button>
                </div>
              )}
            </ol>
          </div>
          
          <div className="bg-[#121212] p-4 rounded">
            <h4 className="text-[#EAEAEA] font-bold mb-2">Important Notes</h4>
            <p className="text-[#888888] text-sm leading-relaxed">{pathway.notes}</p>
          </div>
        </div>
      </div>
    </div>
  );
};