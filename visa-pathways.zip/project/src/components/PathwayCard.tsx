import React from 'react';
import { VisaPathway } from '../types/visa';

interface PathwayCardProps {
  pathway: VisaPathway;
  onViewDetails: (pathway: VisaPathway) => void;
}

export const PathwayCard: React.FC<PathwayCardProps> = ({ pathway, onViewDetails }) => {
  return (
    <div className="bg-[#1A1A1A] border border-[#333333] p-6 rounded-lg">
      <h3 className="text-[#EAEAEA] text-xl font-bold mb-3">{pathway.visa_name}</h3>
      
      <div className="space-y-2 mb-4">
        <div className="flex justify-between text-sm">
          <span className="text-[#888888]">Minimum Income:</span>
          <span className="text-[#EAEAEA] font-medium">€{pathway.income_required_eur}/month</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-[#888888]">Income Type:</span>
          <span className="text-[#EAEAEA] font-medium">{pathway.income_type}</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-[#888888]">Avg. Timeline:</span>
          <span className="text-[#EAEAEA] font-medium">{pathway.avg_timeline_days} days</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-[#888888]">Est. Cost:</span>
          <span className="text-[#EAEAEA] font-medium">${pathway.estimated_cost_usd}</span>
        </div>
      </div>
      
      <p className="text-[#888888] text-sm mb-4 leading-relaxed">{pathway.notes}</p>
      
      <button
        onClick={() => onViewDetails(pathway)}
        className="w-full bg-[#333333] hover:bg-[#444444] text-[#EAEAEA] font-medium py-3 px-4 rounded text-sm transition-colors"
      >
        View Full Checklist & Details
      </button>
    </div>
  );
};