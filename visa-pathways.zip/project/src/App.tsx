import React, { useState } from 'react';
import { VisaPathway } from './types/visa';
import { visaData, countries } from './data/visaData';
import { SearchForm } from './components/SearchForm';
import { ResultsView } from './components/ResultsView';
import { DetailModal } from './components/DetailModal';

function App() {
  const [citizenship, setCitizenship] = useState('');
  const [destination, setDestination] = useState('');
  const [showResults, setShowResults] = useState(false);
  const [selectedPathway, setSelectedPathway] = useState<VisaPathway | null>(null);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (citizenship && destination) {
      setShowResults(true);
    }
  };

  const filteredPathways = visaData.filter(
    pathway => pathway.citizenship === citizenship && pathway.destination === destination
  );

  const handleBackToSearch = () => {
    setShowResults(false);
    setCitizenship('');
    setDestination('');
  };

  const handleViewDetails = (pathway: VisaPathway) => {
    setSelectedPathway(pathway);
  };

  const handleCloseModal = () => {
    setSelectedPathway(null);
  };

  if (showResults) {
    return (
      <>
        <ResultsView
          pathways={filteredPathways}
          countries={countries}
          citizenship={citizenship}
          destination={destination}
          onViewDetails={handleViewDetails}
          onBackToSearch={handleBackToSearch}
        />
        <DetailModal
          pathway={selectedPathway}
          onClose={handleCloseModal}
        />
      </>
    );
  }

  return (
    <SearchForm
      countries={countries}
      citizenship={citizenship}
      destination={destination}
      onCitizenshipChange={setCitizenship}
      onDestinationChange={setDestination}
      onSubmit={handleSearch}
    />
  );
}

export default App;